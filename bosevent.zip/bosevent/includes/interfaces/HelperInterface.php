<?php
namespace includes\interfaces;

interface HelperInterface {
	public function init();
}