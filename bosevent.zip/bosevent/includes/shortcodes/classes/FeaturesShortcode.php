<?php
namespace includes\shortcodes;

class FeaturesShortcode extends \includes\classes\Shortcode {
    public $shortcode = 'features';
    public $full_attrs = true;
}