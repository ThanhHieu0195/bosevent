<?php
namespace includes\shortcodes;

class TeamsShortcode extends \includes\classes\Shortcode {
    public $shortcode = 'teams';
    public $full_attrs = true;
}